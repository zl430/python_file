from flask import Flask
from flask import request
import mysql_operation
app = Flask(__name__)
# @app.route('/', methods=['GET', 'POST'])
# def home():
#     return '<h1>Home</h1>'
# @app.route('/signin', methods=['POST'])
# def signin():
#     # print(request.query_string)
#     if request.form['username'] == 'admin' and request.form['password'] == 'password':
#         from API import dnspod_class
#         add = dnspod_class.dnspod_api_chk('71244700', 'www', '1.1.1.1')
#         add.dns_add()
#         return '<h3>Hello, admin!</h3>'
#     return '<h3>Bad username or password.</h3>'
# @app.route('/login', methods=['GET'])
@app.route('/login', methods=['POST'])
def login():
    # name = request.args.get("username")
    # password = request.args.get("password")
    name = request.form['username']
    password = request.form['password']
    mysql = mysql_operation.connection(username=name, password=password, mail=None)
    over = mysql.login()
    if over == True:
        return '1'
    elif over == False:
        return '2'
    else:
        return '0'
@app.route('/registered', methods=['POST'])
def registered():
    name = request.form['username']
    password = request.form['password']
    mail = request.form['mail']
    mysql = mysql_operation.connection(username=name, password=password, mail=mail)
    over = mysql.create()
    if over == True:
        return '1'
    else:
        return '0'
# @app.route('host_form', methods=['POST'])
# def host_form():
#     mysql = mysql_operation.host_select()
#     over = mysql.host_all()
#     return over
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=66)