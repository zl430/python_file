#coding:utf-8
DBHOST = "10.113.4.189"
DBPORT = 66
DBUSER = "root"
DBPWD = "123456"
DBNAME = "py_test"
DBCHAR = "utf8"
